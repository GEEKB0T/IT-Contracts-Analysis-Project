import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt

# Load dataset
df = pd.read_csv("C:\\Users\\st946\\Downloads\\IT_Contracts_Report_2019_20250409.csv")

# -----------------------------
# 1. Data Cleaning & Preprocessing
# -----------------------------
# Convert date columns to datetime
df['Contract Start Date'] = pd.to_datetime(df['Contract Start Date'], errors='coerce')
df['Contract End Date'] = pd.to_datetime(df['Contract End Date'], errors='coerce')

# Fill missing contractor names
df['Contractor Name D/B/A (Optional)'] = df['Contractor Name D/B/A (Optional)'].fillna("N/A")

# Create new column for contract duration
df['Contract Duration (Days)'] = (df['Contract End Date'] - df['Contract Start Date']).dt.days

# Drop rows with missing or zero Total Contract Amount
df = df[df['Total Contract Amount'].notnull() & (df['Total Contract Amount'] > 0)]

# -----------------------------
# 2. Exploratory Data Analysis (EDA)
# -----------------------------
print("Total Rows:", len(df))
print("Unique Agencies:", df['Agency Name'].nunique())
print("Top 5 Agencies:\n", df['Agency Name'].value_counts().head())
print("\nContract Amount Summary:\n", df['Total Contract Amount'].describe())
print("\nContract Duration Summary:\n", df['Contract Duration (Days)'].describe())

# -----------------------------
# 3. Data Visualization
# -----------------------------
sns.set(style="whitegrid")

# Total Contract Amount by Agency (Top 10)
top_agencies = df.groupby("Agency Name")["Total Contract Amount"].sum().nlargest(10)
plt.figure(figsize=(10, 6))
sns.barplot(x=top_agencies.values, y=top_agencies.index, palette="Set2")
plt.title("Top 10 Agencies by Total Contract Amount")
plt.xlabel("Total Amount ($)")
plt.ylabel("Agency")
plt.tight_layout()
plt.show()

# Distribution of Contract Durations
plt.figure(figsize=(10, 6))
sns.histplot(df['Contract Duration (Days)'].dropna(), bins=40, color="teal", kde=True)
plt.title("Contract Duration Distribution")
plt.xlabel("Duration (Days)")
plt.tight_layout()
plt.show()

# Contract Amount over Year
df['Contract Year'] = df['Contract Start Date'].dt.year
yearly = df.groupby('Contract Year')['Total Contract Amount'].sum()
plt.figure(figsize=(10, 6))
sns.lineplot(x=yearly.index, y=yearly.values, marker='o', color='purple')
plt.title("Total Contract Amount by Year")
plt.xlabel("Year")
plt.ylabel("Amount ($)")
plt.tight_layout()
plt.show()

# -----------------------------
# 4. Predictive Analysis (Basic Trendline)
# -----------------------------
# Simple trendline: Total Contract Amount vs Duration
df_model = df[['Contract Duration (Days)', 'Total Contract Amount']].dropna()

x = df_model['Contract Duration (Days)'].values
y = df_model['Total Contract Amount'].values

# Fit a basic linear regression using numpy
slope, intercept = np.polyfit(x, y, 1)
trend = slope * x + intercept

plt.figure(figsize=(10, 6))
plt.scatter(x, y, alpha=0.3, label='Data Points')
plt.plot(x, trend, color='red', label='Trendline')
plt.title("Trend: Contract Duration vs Amount")
plt.xlabel("Contract Duration (Days)")
plt.ylabel("Total Contract Amount ($)")
plt.legend()
plt.tight_layout()
plt.show()

# -----------------------------
# 5. Automation & Reporting
# -----------------------------
# Save cleaned data
df.to_csv("cleaned_IT_contracts.csv", index=False)

# Summary report as CSV
summary = {
    "Total Rows": len(df),
    "Total Agencies": df['Agency Name'].nunique(),
    "Total Contractors": df['Contractor Name'].nunique(),
    "Total Contract Value": df['Total Contract Amount'].sum(),
    "Average Contract Duration": df['Contract Duration (Days)'].mean()
}
report_df = pd.DataFrame(summary.items(), columns=["Metric", "Value"])
report_df.to_csv("IT_contracts_summary_report.csv", index=False)

print("\n✅ Cleaned data saved as 'cleaned_IT_contracts.csv'")
print("✅ Summary report saved as 'IT_contracts_summary_report.csv'")
